package communication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import application.Board;
import application.Piece;
import gui.LOGINController;

/**
 * @author Caldato Marcel
 * @version 1.0
 *
 *          Class for the Communication between to Games. Is needed for the
 *          Multiplayer.
 */
public class CCommunication {

	// Streams that are needed in this class
	private BufferedReader in;
	private PrintWriter out;
	private ObjectOutputStream ObjectOut;
	private ObjectInputStream ObjectIn;

	//	Creates a Instance of this class with the different Streams
	private CCommunication(Socket sessionSocket, Socket objectSocket) {
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				try {
					in.close();
				} catch (IOException e) {
				}
				out.close();
				try {
					ObjectIn.close();
				} catch (IOException e) {
				}
				try {
					ObjectOut.close();
				} catch (IOException e) {
				}
				try {
					objectSocket.close();
				} catch (IOException e) {
				}
				try {
					sessionSocket.close();
				} catch (IOException e) {
				}

			}
		});
		try {
			out = new PrintWriter(sessionSocket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(sessionSocket.getInputStream()));
			ObjectOut = new ObjectOutputStream(objectSocket.getOutputStream());
			ObjectIn = new ObjectInputStream(objectSocket.getInputStream());
		} catch (IOException e) {
		}
	}

	/**
	 * Creates the connection to Host a Game.
	 * 
	 * @param server An already opened ServerSocket
	 * @return An Instance of the class used for the Session
	 */
	public static CCommunication Create(ServerSocket server) {
		try {
			Socket sessionS = server.accept();
			server.close();
			int port = Integer
					.parseInt((new BufferedReader(new InputStreamReader(sessionS.getInputStream()))).readLine());
			(new PrintWriter(sessionS.getOutputStream(), true)).println(LOGINController.getUsername());
			LOGINController.setEnemyUsername(
					(new BufferedReader(new InputStreamReader(sessionS.getInputStream()))).readLine());
			return new CCommunication(sessionS, new Socket(sessionS.getInetAddress(), port));
		} catch (IOException e) {
		}
		return null;
	}

	/**
	 * Creates a connection with a Host
	 * 
	 * @param host The IP of the Host
	 * @param port The Port of the Host
	 * @return An Instance of the class used for the Session
	 */
	public static CCommunication Connect(String host, int port) {
		try {
			Socket sessionS = new Socket(host, port);
			ServerSocket objectServer = new ServerSocket(0);
			(new PrintWriter(sessionS.getOutputStream(), true)).println(objectServer.getLocalPort());
			LOGINController.setEnemyUsername(
					(new BufferedReader(new InputStreamReader(sessionS.getInputStream()))).readLine());
			(new PrintWriter(sessionS.getOutputStream(), true)).println(LOGINController.getUsername());
			Socket objectSocket = objectServer.accept();
			objectServer.close();
			return new CCommunication(sessionS, objectSocket);
		} catch (IOException e) {
		}
		return null;
	}

	/**
	 * Reads a Message from the Session
	 * 
	 * @return The Message of the Session, null at error
	 */
	public String Rx() {
		try {
			return in.readLine();
		} catch (IOException e) {
			System.exit(0);
		}
		return null;
	}

	/**
	 * To send a Message to the Session
	 * 
	 * @param The Message to write to the Session
	 */
	public void Tx(String msg) {
		out.print(msg);
	}

	/**
	 * Reads a Game Board from the Session
	 * 
	 * @return The Board of the Session, null at error
	 */
	public Board RxObject() {
		try {
			Piece[] Black = (Piece[]) ObjectIn.readObject();
			Piece[] White = (Piece[]) ObjectIn.readObject();
			Board temp = new Board();
			temp.setPiecesBlack(Black);
			temp.setPiecesWhite(White);
			return temp;
		} catch (IOException e) {
		} catch (ClassNotFoundException e) {
				//e.printStackTrace();
		}
		return null;
	}

	/**
	 * To send a Game Board to the Session
	 * 
	 * @param obj The Board to Send
	 */
	public void TxObject(Board obj) {
		try {
			ObjectOut.writeObject(obj.getPiecesBlack());
			ObjectOut.writeObject(obj.getPiecesWhite());
		} catch (IOException e) {
		}
	}
}