package gui;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;

public class MODUSController {
	@FXML
	public Label lbluser;
	@FXML
	public ImageView ivBackground;
	@FXML
	public ImageView ivLogo;
	
	private static boolean multiplayer;
	
	public static boolean getMultiplayer() {
		return multiplayer;
	}
	@FXML
	public void Key_Pressed(KeyEvent e) {
		if(e.getCode().equals(KeyCode.ENTER)) {
			Event.fireEvent(e.getTarget(), new ActionEvent());
		}
	}
	@FXML
	public void initialize(){
		ivBackground.setImage(Main.getBackground());
		ivLogo.setImage(Main.getLogo());
		lbluser.setText("Logged in as " + LOGINController.getUsername());
		
	}
	@FXML
	public void close_click() {
		System.exit(0);
	}
	@FXML
	public void singleplayer_click() {
		multiplayer=false;
		Main.getRoot().getChildren().clear();
		try {
			Parent p = (Pane) FXMLLoader.load(getClass().getResource("GAME.fxml"));
			Main.getRoot().add(p,0,0);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	@FXML
	public void multiplayer_click() {
		multiplayer=true;
		Main.getRoot().getChildren().clear();
		try {
			Parent p = (Pane) FXMLLoader.load(getClass().getResource("MULTIPLAYER_MENU.fxml"));
			Main.getRoot().add(p,0,0);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
}