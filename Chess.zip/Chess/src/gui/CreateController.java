package gui;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;

import com.jfoenix.controls.JFXTextField;

import communication.CCommunication;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class CreateController {

	@FXML
	public JFXTextField txfIP;
	@FXML
	public JFXTextField txfPort;

	@FXML
	public ImageView ivBackground;
	
	@FXML
	public void initialize(){
		ivBackground.setImage(Main.getBackground());

		try {
			ServerSocket server = new ServerSocket(0);
			txfIP.setText(InetAddress.getLocalHost().getHostAddress());
			txfPort.setText(Integer.toString(server.getLocalPort()));
			Thread t = new Thread() {
				public void run() {
					GAMEController.setCommunication(CCommunication.Create(server));
					
					Platform.runLater(new Runnable(){

						@Override
						public void run() {
							Main.getRoot().getChildren().clear();
							try {
								Parent p = (Pane) FXMLLoader.load(getClass().getResource("GAME.fxml"));
								Main.getRoot().add(p,0,0);
							} catch (IOException e) {
								e.printStackTrace();
							}
						}
					});
					
				}
			};
			t.start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	public void back_click() {
		Main.getRoot().getChildren().clear();
		try {
			Parent p = (Pane) FXMLLoader.load(getClass().getResource("MULTIPLAYER_MENU.fxml"));
			Main.getRoot().add(p,0,0);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}