package gui;

import application.AIFunctions;
import application.Board;
import application.Piece;
import communication.CCommunication;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

public class GAMEController {
	@FXML
	Canvas canvas;
	@FXML
	Canvas canvasRight;
	@FXML
	Canvas canvasLeft;
	@FXML
	Label lblStatus;
	@FXML
	Label lblUserRight;
	@FXML
	Label lblUserLeft;
	@FXML
	public ImageView ivBackground;

	private int t = 0;
	private GraphicsContext gc;
	private double scale;
	private Board b;
	private final int DEPTH=4;
	private static Piece selected;
	private static Boolean isWhitesTurn = true;
	private static CCommunication communication;
	private static Image blackPawn;
	private static Image blackRook;
	private static Image blackKnight;
	private static Image blackBishop;
	private static Image blackQueen;
	private static Image blackKing;
	private static Image whitePawn;
	private static Image whiteRook;
	private static Image whiteKnight;
	private static Image whiteBishop;
	private static Image whiteQueen;
	private static Image whiteKing;
	private static int positionXLeft = 0, positionYLeft = 0;
	private static int positionXRight = 0, positionYRight = 0;
	
	public static void setSelected(Piece selected) {
		GAMEController.selected = selected;
	}

	public static void setCommunication(CCommunication Communication) {
		communication = Communication;
	}

	@FXML
	public void initialize() {
		ivBackground.setImage(Main.getBackground());
		lblUserLeft.setText(LOGINController.getUsername());
		lblUserRight.setText(LOGINController.getEnemyUsername());
		if (MODUSController.getMultiplayer()) {
			if (!MMenuController.getServer()) {
				isWhitesTurn = true;
			}
			new Thread() {
				public void run() {
					while (true) {
						b = communication.RxObject();
						isWhitesTurn = !isWhitesTurn;
						Platform.runLater(new Runnable() {

							@Override
							public void run() {
								drawBoard(null);
							}
						});
						if(b==null) break;
					}
				}
			}.start();
		}
		b = new Board();
		scale = (canvas.getHeight() / 8);
		gc = canvas.getGraphicsContext2D();
		loadPieces();
		//if(!b.isDone())b=AIFunctions.minimaxAlphaBetaRoot(b, DEPTH, true);
		drawBoard(null);
		if (isWhitesTurn) {
			lblStatus.setText("Whites turn");
		} else {
			lblStatus.setText("Blacks turn");
		}
	}

	public void writePiece(String letter, double x, double y, Boolean c, int size) {
		if (c) {
			switch (letter) {
			case "K":
				gc.drawImage(whiteKing, x, y, size, size);
				break;
			case "Q":
				gc.drawImage(whiteQueen, x, y, size, size);
				break;
			case "Kn":
				gc.drawImage(whiteKnight, x, y, size, size);
				break;
			case "P":
				gc.drawImage(whitePawn, x, y, size, size);
				break;
			case "R":
				gc.drawImage(whiteRook, x, y, size, size);
				break;
			case "B":
				gc.drawImage(whiteBishop, x, y, size, size);
				break;
			}
		} else {
			{
				switch (letter) {
				case "K":
					gc.drawImage(blackKing, x, y, size, size);
					break;
				case "Q":
					gc.drawImage(blackQueen, x, y, size, size);
					break;
				case "Kn":
					gc.drawImage(blackKnight, x, y, size, size);
					break;
				case "P":
					gc.drawImage(blackPawn, x, y, size, size);
					break;
				case "R":
					gc.drawImage(blackRook, x, y, size, size);
					break;
				case "B":
					gc.drawImage(blackBishop, x, y, size, size);
					break;
				}
			}
		}

	}

	public void printLeft(String letter, Boolean c) {
		int size = 24;
		if (c) {
			switch (letter) {
			case "K":
				canvasLeft.getGraphicsContext2D().drawImage(whiteKing, (positionXLeft * size) + 5,
						(positionYLeft * size) + 5, size, size);
				break;
			case "Q":
				canvasLeft.getGraphicsContext2D().drawImage(whiteQueen, (positionXLeft * size) + 5,
						(positionYLeft * size) + 5, size, size);
				break;
			case "Kn":
				canvasLeft.getGraphicsContext2D().drawImage(whiteKnight, (positionXLeft * size) + 5,
						(positionYLeft * size) + 5, size, size);
				break;
			case "P":
				canvasLeft.getGraphicsContext2D().drawImage(whitePawn, (positionXLeft * size) + 5,
						(positionYLeft * size) + 5, size, size);
				break;
			case "R":
				canvasLeft.getGraphicsContext2D().drawImage(whiteRook, (positionXLeft * size) + 5,
						(positionYLeft * size) + 5, size, size);
				break;
			case "B":
				canvasLeft.getGraphicsContext2D().drawImage(whiteBishop, (positionXLeft * size) + 5,
						(positionYLeft * size) + 5, size, size);
				break;
			}
		} else {
			{
				switch (letter) {
				case "K":
					canvasLeft.getGraphicsContext2D().drawImage(blackKing, (positionXLeft * size) + 5,
							(positionYLeft * size) + 5, size, size);
					break;
				case "Q":
					canvasLeft.getGraphicsContext2D().drawImage(blackQueen, (positionXLeft * size) + 5,
							(positionYLeft * size) + 5, size, size);
					break;
				case "Kn":
					canvasLeft.getGraphicsContext2D().drawImage(blackKnight, (positionXLeft * size) + 5,
							(positionYLeft * size) + 5, size, size);
					break;
				case "P":
					canvasLeft.getGraphicsContext2D().drawImage(blackPawn, (positionXLeft * size) + 5,
							(positionYLeft * size) + 5, size, size);
					break;
				case "R":
					canvasLeft.getGraphicsContext2D().drawImage(blackRook, (positionXLeft * size) + 5,
							(positionYLeft * size) + 5, size, size);
					break;
				case "B":
					canvasLeft.getGraphicsContext2D().drawImage(blackBishop, (positionXLeft * size) + 5,
							(positionYLeft * size) + 5, size, size);
					break;
				}
			}
		}
		positionXLeft++;
		if (positionXLeft > canvasLeft.getWidth()/(size+5)) {

			positionXLeft = 0;
			positionYLeft++;
		}

	}

	public void printRight(String letter, Boolean c) {
		int size = 24;
		if (c) {
			switch (letter) {
			case "K":
				canvasRight.getGraphicsContext2D().drawImage(whiteKing, (positionXRight * size) + 5,
						(positionYRight * size) + 5, size, size);
				break;
			case "Q":
				canvasRight.getGraphicsContext2D().drawImage(whiteQueen, (positionXRight * size) + 5,
						(positionYRight * size) + 5, size, size);
				break;
			case "Kn":
				canvasRight.getGraphicsContext2D().drawImage(whiteKnight, (positionXRight * size) + 5,
						(positionYRight * size) + 5, size, size);
				break;
			case "P":
				canvasRight.getGraphicsContext2D().drawImage(whitePawn, (positionXRight * size) + 5,
						(positionYRight * size) + 5, size, size);
				break;
			case "R":
				canvasRight.getGraphicsContext2D().drawImage(whiteRook, (positionXRight * size) + 5,
						(positionYRight * size) + 5, size, size);
				break;
			case "B":
				canvasRight.getGraphicsContext2D().drawImage(whiteBishop, (positionXRight * size) + 5,
						(positionYRight * size) + 5, size, size);
				break;
			}
		} else {
			{
				switch (letter) {
				case "K":
					canvasRight.getGraphicsContext2D().drawImage(blackKing, (positionXRight * size) + 5,
							(positionYRight * size) + 5, size, size);
					break;
				case "Q":
					canvasRight.getGraphicsContext2D().drawImage(blackQueen, (positionXRight * size) + 5,
							(positionYRight * size) + 5, size, size);
					break;
				case "Kn":
					canvasRight.getGraphicsContext2D().drawImage(blackKnight, (positionXRight * size) + 5,
							(positionYRight * size) + 5, size, size);
					break;
				case "P":
					canvasRight.getGraphicsContext2D().drawImage(blackPawn, (positionXRight * size) + 5,
							(positionYRight * size) + 5, size, size);
					break;
				case "R":
					canvasRight.getGraphicsContext2D().drawImage(blackRook, (positionXRight * size) + 5,
							(positionYRight * size) + 5, size, size);
					break;
				case "B":
					canvasRight.getGraphicsContext2D().drawImage(blackBishop, (positionXRight * size) + 5,
							(positionYRight * size) + 5, size, size);
					break;
				}
			}
		}
		positionXRight++;
		if (positionXRight > canvasRight.getWidth()/(size+5)) {

			positionXRight = 0;
			positionYRight++;
		}

	}

	static public void loadPieces() {
		blackPawn = new Image(GAMEController.class.getResourceAsStream("/Pieces/B_P.png"));
		blackRook = new Image(GAMEController.class.getResourceAsStream("/Pieces/B_R.png"));
		blackBishop = new Image(GAMEController.class.getResourceAsStream("/Pieces/B_B.png"));
		blackKnight = new Image(GAMEController.class.getResourceAsStream("/Pieces/B_N.png"));
		blackQueen = new Image(GAMEController.class.getResourceAsStream("/Pieces/B_Q.png"));
		blackKing = new Image(GAMEController.class.getResourceAsStream("/Pieces/B_K.png"));

		whitePawn = new Image(GAMEController.class.getResourceAsStream("/Pieces/W_P.png"));
		whiteRook = new Image(GAMEController.class.getResourceAsStream("/Pieces/W_R.png"));
		whiteBishop = new Image(GAMEController.class.getResourceAsStream("/Pieces/W_B.png"));
		whiteKnight = new Image(GAMEController.class.getResourceAsStream("/Pieces/W_N.png"));
		whiteQueen = new Image(GAMEController.class.getResourceAsStream("/Pieces/W_Q.png"));
		whiteKing = new Image(GAMEController.class.getResourceAsStream("/Pieces/W_K.png"));
}

	@FXML
	public void close() {
		QUIT.showQuit();
	}
	public void drawBoard(MouseEvent e) {
		if(b==null) {
			Alert.showAlert();
		}
		if (isWhitesTurn) {
			lblStatus.setText("Whites turn");
		} else {
			lblStatus.setText("Blacks turn");
		}
		if (b.isDone()) {
			lblStatus.setText("Game is done!");
		}

		gc.setFill(Color.WHITE);
		gc.strokeRect(0, 0, canvas.getWidth(), canvas.getHeight());
		gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());

		canvasLeft.getGraphicsContext2D().setFill(Color.WHITE);
		canvasLeft.getGraphicsContext2D().strokeRect(0, 0, canvasLeft.getWidth(), canvasLeft.getHeight());
		canvasLeft.getGraphicsContext2D().fillRect(0, 0, canvasLeft.getWidth(), canvasLeft.getHeight());

		canvasRight.getGraphicsContext2D().setFill(Color.WHITE);
		canvasRight.getGraphicsContext2D().strokeRect(0, 0, canvasRight.getWidth(), canvasRight.getHeight());
		canvasRight.getGraphicsContext2D().fillRect(0, 0, canvasRight.getWidth(), canvasRight.getHeight());

		for (int i = 0; i < 8; i++) {
			for (int j = 0; j < 8; j++) {
				if ((i + j) % 2 == 0) {
					if (LOGINController.getUsername().toLowerCase().contains("rainbow")) {
						t++;
						gc.setFill(Color.rgb((t * 25) % 255, (t * 56) % 255, (t * 343) % 255));
					} else {
						// gc.setFill(Color.CORNFLOWERBLUE);
						gc.setFill(Color.LAVENDER);
					}
				} else {
					gc.setFill(Color.WHITE);
				}
				gc.fillRect(i * scale, j * scale, scale, scale);
				if(selected!=null) {
					if(selected.canMoveTo(i, j, b, false)) {
						gc.setFill(Color.gray(0.5, 0.5));
						//gc.fillRect(i * scale, j * scale, scale, scale);
						gc.fillOval(i*scale+20, j*scale+20, scale-40, scale-40);
						Piece piece= b.getPieceAt(i, j);
						if(piece!=null)writePiece(piece.getLetter(), i * scale, j * scale, piece.isWhite(), (int) scale);
					}
				}
			}
		}
		positionXLeft = 0;
		positionYLeft = 0;
		positionXRight = 0;
		positionYRight = 0;
		for (int i = 0; i < 16; i++) {
			Piece p = b.getPiecesWhite()[i];
			if (!p.isAlive()) {
				if (MMenuController.getServer() == p.isWhite()) {
					printLeft(p.getLetter(), MMenuController.getServer());
				} else {
					printRight(p.getLetter(), !MMenuController.getServer());
				}
				continue;
			}
			if (p.equals(selected)) {
				writePiece(p.getLetter(), e.getX() - scale / 2, e.getY() - scale / 2, true, (int) scale);
			} else {
				if (MMenuController.getServer())
					writePiece(p.getLetter(), p.getX() * scale, p.getY() * scale, true, (int) scale);
				else
					writePiece(p.getLetter(), (7 - p.getX()) * scale, (7 - p.getY()) * scale, true, (int) scale);
			}
		}

		for (

				int i = 0; i < 16; i++) {
			Piece p = b.getPiecesBlack()[i];
			if (!p.isAlive()) {
				if (MMenuController.getServer() == p.isWhite()) {
					printLeft(p.getLetter(), MMenuController.getServer());
				} else {
					printRight(p.getLetter(), !MMenuController.getServer());
				}
				continue;
			}
			if (p.equals(selected)) {
				writePiece(p.getLetter(), e.getX() - scale / 2, e.getY() - scale / 2, false, (int) scale);
			} else {
				if (MMenuController.getServer())
					writePiece(p.getLetter(), p.getX() * scale, p.getY() * scale, false, (int) scale);
				else
					writePiece(p.getLetter(), (7 - p.getX()) * scale, (7 - p.getY()) * scale, false, (int) scale);
			}
		}
	}

	public void dragStarted(MouseEvent e) {
		if (isWhitesTurn) {
			lblStatus.setText("Whites turn");
		} else {
			lblStatus.setText("Blacks turn");
		}
		if (b.isDone()) {
			lblStatus.setText("Game is done!");
			return;
		}
		Piece p;
		if (!MMenuController.getServer())
			p = b.getPieceAt((7 - (int) (e.getX() / scale)), (7 - (int) (e.getY() / scale)));
		else
			p = b.getPieceAt((int) (e.getX() / scale), (int) (e.getY() / scale));
		if (MODUSController.getMultiplayer()) {
			if (MMenuController.getServer() == isWhitesTurn) {
				if (p != null && p.isAlive() && (p.isWhite() == isWhitesTurn))
					selected = p;
				else
					selected = null;
			}

		} else {
			if (p != null && p.isAlive() && (p.isWhite() == isWhitesTurn) && isWhitesTurn)
				selected = p;
			else
				selected = null;
		}

	}

	public void dragged(MouseEvent e) {
		drawBoard(e);
	}

	public void dragEnded(MouseEvent e) {
		if (selected == null) {
			return;
		}

		if ((!(selected.canMoveTo((int) (e.getX() / scale), (int) (e.getY() / scale), b, true)
				&& !((int) (e.getX() / scale) == selected.getX() && (int) (e.getY() / scale) == selected.getY()))
				&& MMenuController.getServer())
				|| (!(selected.canMoveTo(7 - (int) (e.getX() / scale), 7 - (int) (e.getY() / scale), b, true)
						&& !(7 - (int) (e.getX() / scale) == 7 - selected.getX()
								&& 7 - (int) (e.getY() / scale) == (7 - selected.getY())))
						&& !MMenuController.getServer())) {
			selected = null;
			drawBoard(e);
		} else {
			if (MMenuController.getServer())
				selected.move((int) (e.getX() / scale), (int) (e.getY() / scale), b);
			else
				selected.move(7 - (int) (e.getX() / scale), 7 - (int) (e.getY() / scale), b);
			isWhitesTurn = !isWhitesTurn;
			selected = null;
			drawBoard(e);
			if (MODUSController.getMultiplayer()) {
				communication.TxObject(b);
			} else {
				if (!b.isDone())
					new Thread() {
						public void run() {
							b = AIFunctions.minimaxAlphaBetaRoot(b, DEPTH, false);
							isWhitesTurn = !isWhitesTurn;
							Platform.runLater(new Runnable() {

								@Override
								public void run() {
									drawBoard(e);
								}
							});
						}
					}.start();
			}
		}
	}

}
