package gui;

import java.io.IOException;

import application.Bishop;
import application.Knight;
import application.Piece;
import application.Queen;
import application.Rook;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class ChoosePiece {
	
	private static Piece piece;
	private static int PieceX,PieceY;
	private static boolean PieceisWhite;
	
	private void closeStage(ActionEvent event) {
        Node  source = (Node)  event.getSource(); 
        Stage stage  = (Stage) source.getScene().getWindow();
        stage.close();
    }
	
	@FXML
	public void queen_click(ActionEvent event){
		piece = new Queen(PieceX,PieceY,PieceisWhite);
		closeStage(event);
	}
	@FXML
	public void knight_click(ActionEvent event){
		piece = new Knight(PieceX, PieceY, PieceisWhite);
		closeStage(event);
	}
	@FXML
	public void bishop_click(ActionEvent event){
		piece = new Bishop(PieceX, PieceY, PieceisWhite);
		closeStage(event);
	}
	@FXML
	public void rook_click(ActionEvent event){
		piece = new Rook(PieceX, PieceY, PieceisWhite);
		closeStage(event);
	}
	
	@FXML
	public void key_pressed(KeyEvent e) {
		if(e.getCode().equals(KeyCode.ENTER)) {
			Event.fireEvent(e.getTarget(), new ActionEvent());
		}
	}
	public static Piece showChooseDialog(int x, int y,boolean isWhite) {
		piece = null;
		PieceX=x;
		PieceY=y;
		PieceisWhite=isWhite;
		FXMLLoader fxmlLoader = new FXMLLoader(ChoosePiece.class.getResource("Pieces.fxml"));
        Parent parent;
		try {
			parent = fxmlLoader.load();
			Scene scene = new Scene(parent, 150, 300);
			scene.setFill(Color.TRANSPARENT);
	        Stage stage = new Stage();
	        stage.initModality(Modality.APPLICATION_MODAL);
			stage.initStyle(StageStyle.TRANSPARENT);
	        stage.setScene(scene);
	        stage.showAndWait();
			return piece;
		} catch (IOException e) {
			e.printStackTrace();
		}

        return null;
	}
}