package gui;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;

public class Main extends Application {
	private static GridPane root = new GridPane();
	private static Image logo =  new Image(Main.class.getResourceAsStream("/img/chess_logo.png"));
	private static Image background =  new Image(Main.class.getResourceAsStream("/img/chess.jpg"));

	

	public static Image getLogo() {
		return logo;
	}

	public static Image getBackground() {
		return background;
	}

	public static GridPane getRoot() {
		return root;
	}

	@Override
	public void start(Stage primaryStage) {
		try {
			root.setAlignment(Pos.CENTER);
			Parent p = FXMLLoader.load(getClass().getResource("LOGIN.fxml"));
			root.add(p, 0, 0);
			root.setBackground(Background.EMPTY);
			Scene scene = new Scene(root, 1000, 750);
			scene.setFill(Color.TRANSPARENT);
			primaryStage.setResizable(false);
			primaryStage.initStyle(StageStyle.TRANSPARENT);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
