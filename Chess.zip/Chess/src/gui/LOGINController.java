package gui;

import java.io.IOException;


import com.jfoenix.controls.JFXTextField;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;

public class LOGINController {
	@FXML
	public JFXTextField txfUser;
	@FXML
	public ImageView ivBackground;
	@FXML
	public ImageView ivLogo;
	
	private static String EnemyUsername="Computer";
	private static String Username;
	
	public static String getUsername() {
		return Username;
	}
	
	public static String getEnemyUsername() {
		return EnemyUsername;
	}

	public static void setEnemyUsername(String enemyUsername) {
		EnemyUsername = enemyUsername;
	}
	
	@FXML
	public void initialize() {
		ivBackground.setImage(Main.getBackground());
		ivLogo.setImage(Main.getLogo());
	}
	@FXML
	public void close_click() {
		System.exit(0);
	}
	@FXML
	public void Key_Pressed(KeyEvent e) {
		if(e.getCode().equals(KeyCode.ENTER)) {
			login_click();
		}
	}
	@FXML
	public void login_click() {
		if(txfUser.getText().isEmpty()) {
			txfUser.setText("Guest"+(int)(Math.random()*100));
		}
		Username=txfUser.getText();
		Main.getRoot().getChildren().clear();
		try {
			Parent p = (Pane) FXMLLoader.load(getClass().getResource("MODUS.fxml"));
			Main.getRoot().add(p,0,0);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
}