package gui;

import java.io.IOException;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class QUIT {
	
	@FXML
	public void key_pressed(KeyEvent e) {
		if(e.getCode().equals(KeyCode.ENTER)) {
			Event.fireEvent(e.getTarget(), new ActionEvent());
		}
	}
	
	@FXML
	private void close_click(ActionEvent event) {
        System.exit(0);
    }
	
	@FXML
	private void back_click(ActionEvent event) {
        Node  source = (Node)  event.getSource(); 
        Stage stage  =
        		(Stage) source.getScene().getWindow();
        stage.close();
	}
	
	public static void showQuit() {
		Platform.runLater(new Runnable() {

			@Override
			public void run() {
				FXMLLoader fxmlLoader = new FXMLLoader(QUIT.class.getResource("QUIT.fxml"));
		        Parent parent;
				try {
					parent = fxmlLoader.load();
					Scene scene = new Scene(parent, 455, 200);
					scene.setFill(Color.TRANSPARENT);
			        Stage stage = new Stage();
			        stage.initModality(Modality.APPLICATION_MODAL);
					stage.initStyle(StageStyle.TRANSPARENT);
			        stage.setScene(scene);
			        stage.showAndWait();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		
	}
}