package application;

import java.util.ArrayList;

/**
* Implementierung der Funktionen fuer die Berechnung des naechstbesten Zuges anhand
* der Minimax Methode, ein Algorithmus zur Ermittlung der optimalen Spielstrategie 
* fuer endliche Zwei-Personen-Nullsummenspiele mit perfekter Information.
* Zusoetzlich wurde Alpha-Beta-Pruning implementiert, das ist eine Optimierung, bei der
* Teile der Suchbaumes, die nicht ueberprueft werden muessen, ausgelassen werden.
* @author  Matscher Maximilian
* @author  Gabriel Fischer
*/

public class AIFunctions {
	
	static boolean endGame;
	
	/**
	 * Startfunktion der Minimax implementierung. Errechnet rekursiv aus dem aktuellen Spielbrett
	 * je nach Suchtiefe den besten naechsten Zug fuer der jeweiligen Spieler.
	 * @param b Das Spielbrett mit dem gespielt wird
	 * @param depth Die Suchtiefe des Algorithmus, 
	 * bestimmt Geschwindigkeit und Genauigkeit des Algorithmus.
	 * Werte zwischen 1 und 4 sind sinnvoll
	 * @param isWhite Legt fest welcher Spieler an der Reihe ist und somit fuer wen der
	 * naechste Zug berechnet wird
	 * @return Gibt das neue Spielbrett, mit gemachten besten Zug zurueck
	 */
	public static Board minimaxAlphaBetaRoot(Board b, int depth,boolean isWhite) {
		Board currentBest=null;
		ArrayList<Board> boards= b.getTurnsBlack();
		int currentBestValue = -100000;
		endGame=b.isEndgame();
		if(endGame) {
			b.getPiecesBlack()[0].squareTable =((King)b.getPiecesBlack()[0]).squareTableEndgame;
		}
		
		int start= (int)(Math.random()*(boards.size()-1));
		for(int i=0; i<boards.size();i++) {
			Board nextBoard= boards.get((i+start)%boards.size());
			int value;
			if(!endGame?nextBoard.isDone():nextBoard.isDone(isWhite)) {
				value=nextBoard.getValue();
			}else {
				value = minmaxAlphaBeta(nextBoard,depth-1,-100000,100000,!isWhite);
			}
			if(value>=currentBestValue) {
				currentBestValue = value;
				currentBest = nextBoard;
			}
		}
		return currentBest;
		
	}
	
	static int minmaxAlphaBeta(Board b, int depth,int alpha,int beta, boolean isWhite) {
		if(depth==0) {
			return b.getValue();
		}
		ArrayList<Board> boards;
		if(isWhite) {
			boards= b.getTurnsWhite();
		}else {
			boards= b.getTurnsBlack();
		}
		
		if(!isWhite) {
			int bestMove = -100000;
			for(Board board: boards) {
				if(!endGame?!board.isDone():!board.isDone(isWhite)) {
					bestMove = Math.max(bestMove, minmaxAlphaBeta(board,depth-1,alpha,beta,!isWhite));
				}else {
					bestMove=Math.max(bestMove, board.getValue());
				}
				alpha=Math.max(alpha, bestMove);
				if(beta<=alpha) {
					return bestMove;
				}
			}
			return bestMove;
		}else {
			int bestMove = 100000;
			for(Board board: boards) {
				if(!endGame?!board.isDone():!board.isDone(isWhite)) {
					bestMove = Math.min(bestMove, minmaxAlphaBeta(board,depth-1,alpha,beta,!isWhite));
				}else {
					bestMove=Math.min(bestMove, board.getValue());
				}
				alpha=Math.min(alpha, bestMove);
				if(beta<=alpha) {
					return bestMove;
				}
			}
			return bestMove;
		}
	}

}
