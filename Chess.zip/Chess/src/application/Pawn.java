package application;

import java.util.ArrayList;

import gui.ChoosePiece;
import gui.GAMEController;

/**
 * Implementierung der Spielfigur Bauer.
 * @author  Matscher Maximilian
 * @author  Gabriel Fischer
 */
public class Pawn extends Piece {
	private static final long serialVersionUID = 1561159894952679672L;
	boolean firstTurn=true;

	/**
	 * Beinhaltet eine 2-Dimensionales Array, je nach Position einen anderen
	 * Wert fuer den Spielstein festlegt. (Wird fuer den AI-Algorithmus gebraucht)
	 */
	static public int [][] pieceTable= {{0,  0,  0,  0,  0,  0,  0,  0,},
			{50, 50, 50, 50, 50, 50, 50, 50,},
			{10, 10, 20, 30, 30, 20, 10, 10,},
			 {5,  5, 10, 25, 25, 10,  5,  5,},
			 {0,  0,  0, 20, 20,  0,  0,  0,},
			 {5, -5,-10,  0,  0,-10, -5,  5,},
			 {5, 10, 10,-20,-20, 10, 10,  5,},
			 {0,  0,  0,  0,  0,  0,  0,  0}};
	
	/**
	 * Konstruiert einen neuen Spielstein an den gegebenen Koordinaten mit der gegebenen Farbe.
	 * @param x X-Koordinate
	 * @param y Y-Koordinate
	 * @param isWhite Farbe als boolean. true=weiß, false=scharz
	 */
	public Pawn(int x, int y, boolean isWhite) {
		super(x, y, isWhite);
		this.setLetter("P");
		this.setValue(100);
		squareTable = pieceTable;
	}
	
	/**
	 * Gibt an, ob sich eine Spielfigur an die neue Position bewegen kann.
	 * @param x neue X-Koordinate
	 * @param y neue Y-Koordinate
	 * @param b das Spielbrett
	 * @param checkCheck wird intern genutzt um ueberpruefungen ohne auswirkung aus das Spielfeld zu machen. Default=true.
	 * @return boolean
	 */
	public boolean canMoveTo(int x, int y, Board b, boolean checkCheck) {
		if (!this.withinBounds(x, y)) {
			return false;
		}
		if (this.attackFriend(x, y, b)) {
			return false;
		}
		Piece attacking = b.getPieceAt(x, y);
		if (attacking!=null && attacking.isAlive()) {
			if (Math.abs(x - this.getX()) == Math.abs(y - this.getY()) &&
			((this.isWhite() && (y - this.getY()) == -1) || (!this.isWhite() &&
		    (y - this.getY()) == 1))) {
				if(checkCheck) {
					if(!b.isCheck(this.isWhite(), x, y, this)) {
						if((y==0 && this.isWhite()) || (y==7 && !this.isWhite())) doTransform(b);
						this.firstTurn = false;
						return true;
					}
				}else {
					return true;
				}
		    }
		    return false;
		}
		if (x != this.getX()) {
			return false;
		}
		if ((this.isWhite() && y - this.getY() == -1) || (!this.isWhite() && y - this.getY() == 1)) {
			if(checkCheck) {
				if(!b.isCheck(this.isWhite(), x, y, this)) {
					if((y==0 && this.isWhite()) || (y==7 && !this.isWhite())) doTransform(b);
					this.firstTurn = false;
					return true;
				}
			}else {
				return true;
			}
		}
		if (this.firstTurn && ((this.isWhite() && y - this.getY() == -2) || 
		(!this.isWhite() && y - this.getY() == 2))) {
		      if (!this.movesThroughPiece(x, y, b)) {
		    	  if(checkCheck) {
			    	  if(!b.isCheck(this.isWhite(), x, y, this)) {
			    		  this.firstTurn = false;
			    		  return true;
			    	  }
		    	  }else {
		    		  return true;
		    	  }
		      }
		}
		return false;
	}
	
	private void doTransform(Board b) {
		Piece p= ChoosePiece.showChooseDialog(this.getX(), this.getY(), this.isWhite());
		GAMEController.setSelected(p);
		swapPiece(b, p);
		
	}
	
	private void swapPiece(Board b, Piece newPiece) {
		Piece[] pieces;
		if(this.isWhite()) {
			pieces= b.getPiecesWhite();
		}else {
			pieces= b.getPiecesBlack();
		}
		int i;
		for(i=0; i<16;i++) {
			if(this.equals(pieces[i])) break;
		}
		pieces[i]=newPiece;
	}
	
	/**
	 * Gibt eine Kopie der Spielsteins zurueck.
	 * @return ein neuer Spielstein.
	 */
	public Pawn clone() {
		Pawn cloned = new Pawn(this.getX(), this.getY(), this.isWhite());
		cloned.setAlive(this.isAlive());
		cloned.firstTurn=this.firstTurn;
		return cloned;
	}
	
	private void movePiece(Board b, int x, int y) {
		Piece piece =b.getPieceAt(this.getX(), this.getY());
		if(piece==null)return;
		if(piece.getClass().equals(Pawn.class)) {
			Pawn pawn= (Pawn) piece;
			pawn.firstTurn = false;
			pawn.move(x, y, b);
		}else {
			piece.move(x, y, b);
		}
		
	}
	
	/**
	 * Gibt alle moeglichen Zuege der Spielfigur als Collection von neuen Spielbrettern zurueck.
	 * (Wird fuer den AI-Algorithmus benoetigt)
	 * @param board das aktuelle SPielfeld
	 * @return eine Collection von Boards.
	 */
	public ArrayList<Board> getTurns(Board b){
		ArrayList<Board> boards= new ArrayList<Board>();
		
		for (int i = -1; i < 2; i += 2) {
			int x = this.getX() + i;
			int y;
			if (this.isWhite()) {
				y = this.getY() - 1;
			} else {
				y = this.getY() + 1;
			}
			Piece attacking = b.getPieceAt(x, y);
			if (attacking!=null) {
				if (!this.attackFriend(x, y, b)) {
					if(!b.isCheck(this.isWhite(), x, y, this)) {
						if((y==0 && this.isWhite()) || (y==7 && !this.isWhite())) {
							
							Board cloned= b.clone();
							swapPiece(cloned, new Queen(this.getX(),this.getY(), this.isWhite()));
							movePiece(cloned, x,y);
							boards.add(cloned);
							cloned= b.clone();
							swapPiece(cloned, new Knight(this.getX(),this.getY(), this.isWhite()));
							movePiece(cloned, x,y);
							boards.add(cloned);
							cloned= b.clone();
							swapPiece(cloned, new Bishop(this.getX(),this.getY(), this.isWhite()));
							movePiece(cloned, x,y);
							boards.add(cloned);
							cloned= b.clone();
							swapPiece(cloned, new Rook(this.getX(),this.getY(), this.isWhite()));
							movePiece(cloned, x,y);
							boards.add(cloned);
						}else {
							Board cloned= b.clone();
							movePiece(cloned, x,y);
							boards.add(cloned);
						}
					}
				}
			}
		}

		int x = this.getX();
		int y;
		if (this.isWhite()) {
			y = this.getY() - 1;
		} else {
			y = this.getY() + 1;
    	}
		if ((b.getPieceAt(x, y)==null||!b.getPieceAt(x, y).isAlive()) && this.withinBounds(x, y)) {
			if(!b.isCheck(this.isWhite(), x, y, this)) {
				if((y==0 && this.isWhite()) || (y==7 && !this.isWhite())) {
					Board cloned= b.clone();
					swapPiece(cloned, new Queen(this.getX(),this.getY(), this.isWhite()));
					movePiece(cloned, x,y);
					boards.add(cloned);
					cloned= b.clone();
					swapPiece(cloned, new Knight(this.getX(),this.getY(), this.isWhite()));
					movePiece(cloned, x,y);
					boards.add(cloned);
					cloned= b.clone();
					swapPiece(cloned, new Bishop(this.getX(),this.getY(), this.isWhite()));
					movePiece(cloned, x,y);
					boards.add(cloned);
					cloned= b.clone();
					swapPiece(cloned, new Rook(this.getX(),this.getY(), this.isWhite()));
					movePiece(cloned, x,y);
					boards.add(cloned);
				}
				Board cloned= b.clone();
				movePiece(cloned, x,y);
				boards.add(cloned);
			}
		}
		
		if (this.firstTurn) {
			if (this.isWhite()) {
				y = this.getY() - 2;
			} else {
				y = this.getY() + 2;
			}
			if ((b.getPieceAt(x, y)==null||!b.getPieceAt(x, y).isAlive()) && this.withinBounds(x, y)) {
				if (!this.movesThroughPiece(x, y, b)) {
					if(!b.isCheck(this.isWhite(), x, y, this)) {
						Board cloned= b.clone();
						movePiece(cloned, x,y);
						boards.add(cloned);
					}
	        	}
			}
		}
		return boards;
	}

}
