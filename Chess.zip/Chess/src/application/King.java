package application;

import java.util.ArrayList;

/**
 * Implementierung des Spielsteins Koenig.
 * @author  Matscher Maximilian
 * @author  Gabriel Fischer
 */
public class King extends Piece {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1406913289081160356L;
	boolean firstTurn=true;
	
	/**
	 * Beinhaltet eine 2-Dimensionales Array, je nach Position einen anderen
	 * Wert fuer den Spielstein festlegt. (Wird fuer den AI-Algorithmus gebraucht.
	 */
	int [][] pieceTable= {
			{-30,-40,-40,-50,-50,-40,-40,-30,},
			{-30,-40,-40,-50,-50,-40,-40,-30,},
			{-30,-40,-40,-50,-50,-40,-40,-30,},
			{-30,-40,-40,-50,-50,-40,-40,-30,},
			{-20,-30,-30,-40,-40,-30,-30,-20,},
			{-10,-20,-20,-20,-20,-20,-20,-10,},
			 {20, 20,  0,  0,  0,  0, 20, 20,},
			 {20, 30, 10,  0,  0, 10, 30, 20},
	};
	
	/**
	 * Beinhaltet eine 2-Dimensionales Array, je nach Position einen anderen
	 * Wert fuer den Spielstein festlegt. (Wird fuer den AI-Algorithmus gebraucht.
	 * Ist wie pieceTable, jedoch mit anderen Werten, die im Endgame(später Verlauf
	 * des Spiels) ändern.
	 */
	public int [][] squareTableEndgame= {
			{-50,-40,-30,-20,-20,-30,-40,-50,},
				{-30,-20,-10,  0,  0,-10,-20,-30,},
				{-30,-10, 20, 30, 30, 20,-10,-30,},
				{-30,-10, 30, 40, 40, 30,-10,-30,},
				{-30,-10, 30, 40, 40, 30,-10,-30,},
				{-30,-10, 20, 30, 30, 20,-10,-30,},
				{-30,-30,  0,  0,  0,  0,-30,-30,},
				{-50,-30,-30,-30,-30,-30,-30,-50}
	};
	
	/**
	 * Konstruiert einen neuen Spielstein an den gegebenen Koordinaten mit der gegebenen Farbe.
	 * @param x X-Koordinate
	 * @param y Y-Koordinate
	 * @param isWhite Farbe als boolean. true=weiß, false=scharz
	 */
	public King(int x, int y, boolean isWhite) {
		super(x, y, isWhite);
		this.setLetter("K");
		this.setValue(20000);
		squareTable= pieceTable;
	}

	/**
	 * Gibt an, ob sich eine Spielfigur an die neue Position bewegen kann.
	 * @param x neue X-Koordinate
	 * @param y neue Y-Koordinate
	 * @param b das Spielbrett
	 * @param checkCheck wird intern genutzt um ueberpruefungen ohne auswirkung aus das Spielfeld zu machen. Default=true.
	 * @return boolean
	 */
	public boolean canMoveTo(int x, int y, Board b, boolean checkCheck) {
		if (!this.withinBounds(x, y)) {
			return false;
	    }
	    if (this.attackFriend(x, y, b)) {
	    	return false;
	    }
	    if (Math.abs(x - this.getX()) <= 1 && Math.abs(y - this.getY()) <= 1) {
	    	if(checkCheck) {
	    		if(!b.isCheck(this.isWhite(), x, y, this)) {
	    			this.firstTurn = false;
	    			return true;
	    		}
	    	}else {
    			return true;
	    	}
	    }
	    if(this.firstTurn) {
	    	if(this.isWhite()) {
	    		if(x==2&&y==7 && ((Rook)(b.getPiecesWhite()[5])).firstTurn
	    		   && ((Rook)(b.getPiecesWhite()[5])).isAlive()) {
	    				if((b.getPieceAt(3, 7)==null || !b.getPieceAt(3, 7).isAlive()) &&
	    						(b.getPieceAt(2, 7)==null || !b.getPieceAt(2, 7).isAlive()) &&
	    						(b.getPieceAt(1, 7)==null || !b.getPieceAt(1, 7).isAlive())) {
	    						if(checkCheck) {
	    							if(!b.isCheck(this.isWhite(), this.getX(), this.getY(), this)){
			    						if(!b.isCheck(this.isWhite(), x, y, this)) {
			    							this.firstTurn=false;
			    							((Rook)b.getPieceAt(0, 7)).firstTurn=false;
			    							b.getPieceAt(0, 7).move(3,7, b);
			    							return true;
			    						}
	    							}
	    						}else {
	    							return true;
	    						}
			    		}
			
	    		}else if(x==6&&y==7 && ((Rook)(b.getPiecesWhite()[7])).firstTurn
	    		   && ((Rook)(b.getPiecesWhite()[7])).isAlive()){
	    			if((b.getPieceAt(6, 7)==null || !b.getPieceAt(6, 7).isAlive()) &&
    						(b.getPieceAt(5, 7)==null || !b.getPieceAt(5, 7).isAlive())) {
	    				if(checkCheck) {
	    					if(!b.isCheck(this.isWhite(), this.getX(), this.getY(), this)){
			    				if(!b.isCheck(this.isWhite(), x, y, this)) {
		    							this.firstTurn=false;
		    							((Rook)b.getPieceAt(7, 7)).firstTurn=false;
		    							b.getPieceAt(7, 7).move(5,7, b);
		    							return true;
			    				}
	    					}
	    				}else {
							return true;
	    				}
		    		}
	    			
	    		}
	    		
	    	}else {
	    		if(x==2&&y==0 && ((Rook)(b.getPiecesBlack()[5])).firstTurn
	 	    		   && ((Rook)(b.getPiecesBlack()[5])).isAlive()) {
	 	    				if((b.getPieceAt(3, 0)==null || !b.getPieceAt(3, 0).isAlive()) &&
	 	    						(b.getPieceAt(2, 0)==null || !b.getPieceAt(2, 0).isAlive()) &&
	 	    						(b.getPieceAt(1, 0)==null || !b.getPieceAt(1, 0).isAlive())) {
	 	    					if(checkCheck) {
	 	    						if(!b.isCheck(this.isWhite(), this.getX(), this.getY(), this)){
			 	    					if(!b.isCheck(this.isWhite(), x, y, this)) {
			 	    							this.firstTurn=false;
			 	    							((Rook)b.getPieceAt(0, 0)).firstTurn=false;
			 	    							b.getPieceAt(0, 0).move(3,0, b);
			 	    							return true;
			 	    					}
	 	    						}
	 	    					}else {
 	    							return true;
	 	    					}
	 			    		}
	 			
	 	    		}else if(x==6&&y==0 && ((Rook)(b.getPiecesBlack()[7])).firstTurn
	 	    		   && ((Rook)(b.getPiecesBlack()[7])).isAlive()){
	 	    			if((b.getPieceAt(6, 0)==null || !b.getPieceAt(6, 0).isAlive()) &&
	     						(b.getPieceAt(5, 0)==null || !b.getPieceAt(5, 0).isAlive())) {
	 	    				if(checkCheck) {
	 	    					if(!b.isCheck(this.isWhite(), this.getX(), this.getY(), this)){
			 	    				if(!b.isCheck(this.isWhite(), x, y, this)) {
			     							this.firstTurn=false;
			     							((Rook)b.getPieceAt(7, 0)).firstTurn=false;
			     							b.getPieceAt(7, 0).move(5,0, b);
			     							return true;
			 	    				}
	 	    					}
	 	    				}else {
     							return true;
	 	    				}
	 		    		}
	 	    			
	 	    		}
	    	}
	    }
	    return false;
	}
	
	/**
	 * Gibt alle moeglichen Zuege der Spielfigur als Collection von neuen Spielbrettern zurueck.
	 * (Wird fuer den AI-Algorithmus benoetigt)
	 * @param board das aktuelle SPielfeld
	 * @return eine Collection von Boards.
	 */
	public ArrayList<Board> getTurns(Board b){
		ArrayList<Board> boards= new ArrayList<Board>();
		for (int i=-1; i < 2; i++) {
			for (int j=-1; j < 2; j++) {
				int tmpX = this.getX() + i;
		        int tmpY = this.getY() + j;
		        if (this.withinBounds(tmpX, tmpY)) {
		        	if (i != 0 || j != 0) {
		        		if (!this.attackFriend(tmpX, tmpY, b)) {
		        			if(!b.isCheck(this.isWhite(), tmpX, tmpY, this)) {
			        			Board cloned= b.clone();
								King pawn = (King)cloned.getPieceAt(this.getX(), this.getY());
								pawn.firstTurn = false;
								cloned.getPieceAt(this.getX(), this.getY()).move(tmpX, tmpY, cloned);
								boards.add(cloned);
		        			}
		        		}
		        	}
		        }
			}
		}
		
		if(this.firstTurn) {
			if(this.isWhite()) {
				if(((Rook)(b.getPiecesWhite()[5])).firstTurn==true &&  ((Rook)(b.getPiecesWhite()[5])).isAlive()) {
					if((b.getPieceAt(3, 7)==null || !b.getPieceAt(3, 7).isAlive()) &&
					   (b.getPieceAt(2, 7)==null || !b.getPieceAt(2, 7).isAlive()) &&
					   (b.getPieceAt(1, 7)==null || !b.getPieceAt(1, 7).isAlive())) {
						if(!b.isCheck(this.isWhite(), 2, 7, this)) {
									Board cloned= b.clone();
									King pawn = (King)cloned.getPieceAt(this.getX(), this.getY());
									pawn.firstTurn = false;
									cloned.getPieceAt(this.getX(), this.getY()).move(2, 7, cloned);
									Rook rook = (Rook)cloned.getPieceAt(0,7);
									rook.firstTurn = false;
									cloned.getPieceAt(0, 7).move(3, 7, cloned);
									boards.add(cloned);
						}
							}
				}
				if(((Rook)(b.getPiecesWhite()[7])).firstTurn==true && ((Rook)(b.getPiecesWhite()[7])).isAlive()) {
					if((b.getPieceAt(5, 7)==null || !b.getPieceAt(5, 7).isAlive()) &&
					   (b.getPieceAt(6, 7)==null || !b.getPieceAt(6, 7).isAlive())) {
						if(!b.isCheck(this.isWhite(), 6, 7, this)) {
							Board cloned= b.clone();
							King pawn = (King)cloned.getPieceAt(this.getX(), this.getY());
							pawn.firstTurn = false;
							cloned.getPieceAt(this.getX(), this.getY()).move(6, 7, cloned);
							Rook rook = (Rook)cloned.getPieceAt(7,7);
							rook.firstTurn = false;
							cloned.getPieceAt(7, 7).move(5, 7, cloned);
							boards.add(cloned);
						}
					}
				}
			}else {
				if(((Rook)(b.getPiecesBlack()[5])).firstTurn==true && ((Rook)(b.getPiecesBlack()[5])).isAlive()) {
					if((b.getPieceAt(3, 0)==null || !b.getPieceAt(3, 0).isAlive()) &&
					   (b.getPieceAt(2, 0)==null || !b.getPieceAt(2, 0).isAlive()) &&
					   (b.getPieceAt(1, 0)==null || !b.getPieceAt(1, 0).isAlive())) {
						if(!b.isCheck(this.isWhite(), 2, 0, this)) {
									Board cloned= b.clone();
									King pawn = (King)cloned.getPieceAt(this.getX(), this.getY());
									pawn.firstTurn = false;
									cloned.getPieceAt(this.getX(), this.getY()).move(2, 0, cloned);
									Rook rook = (Rook)cloned.getPieceAt(0,0);
									rook.firstTurn = false;
									cloned.getPieceAt(0, 0).move(3, 0, cloned);
									boards.add(cloned);
						}
							}
				}
				if(((Rook)(b.getPiecesBlack()[7])).firstTurn==true && ((Rook)(b.getPiecesBlack()[7])).isAlive()) {
					if((b.getPieceAt(5, 0)==null || !b.getPieceAt(5, 0).isAlive()) &&
					   (b.getPieceAt(6, 0)==null || !b.getPieceAt(6, 0).isAlive())) {
						if(!b.isCheck(this.isWhite(), 6, 0, this)) {
							Board cloned= b.clone();
							King pawn = (King)cloned.getPieceAt(this.getX(), this.getY());
							pawn.firstTurn = false;
							cloned.getPieceAt(this.getX(), this.getY()).move(6, 0, cloned);
							Rook rook = (Rook)cloned.getPieceAt(7,0);
							rook.firstTurn = false;
							cloned.getPieceAt(7, 0).move(5, 0, cloned);
							boards.add(cloned);
						}
					}
				}
			}
		}
		
		return boards;
	}
	
	/**
	 * Gibt an, ob der Koenig schach steht, also im nächsten Zug aus dem Spiel genommen werden koennte.
	 * @param b das Spielbrett
	 * @param isWhite welcher Spieler an der Reihe ist.
	 * @return boolean
	 */
	public boolean isCheck(Board b, boolean isWhite) {
		if(isWhite) {
			for(Piece p:b.getPiecesBlack()) {
				if(p.isAlive() && p.canMoveTo(this.getX(), this.getY(), b, false)) {
					return true;
				}
			}
		}else {
			for(Piece p:b.getPiecesWhite()) {
				if(p.isAlive() && p.canMoveTo(this.getX(), this.getY(), b, false)) {
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Gibt eine Kopie der Spielsteins zurueck.
	 * @return ein neuer Spielstein.
	 */
	public King clone() {
		King cloned = new King(this.getX(), this.getY(), this.isWhite());
		cloned.setAlive(this.isAlive());
		cloned.firstTurn=this.firstTurn;
		return cloned;
	}

}