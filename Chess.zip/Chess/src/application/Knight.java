package application;

import java.util.ArrayList;

/**
 * Implementierung des Spielsteins Springer
 * @author  Matscher Maximilian
 * @author  Gabriel Fischer
 */
public class Knight extends Piece {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1489021937727539015L;

	/**
	 * Beinhaltet eine 2-Dimensionales Array, je nach Position einen anderen
	 * Wert fuer den Spielstein festlegt. (Wird fuer den AI-Algorithmus gebraucht)
	 */
	static public int [][] pieceTable= {{-50,-40,-30,-30,-30,-30,-40,-50,},
			{-40,-20,  0,  0,  0,  0,-20,-40,},
			{-30,  0, 10, 15, 15, 10,  0,-30,},
			{-30,  5, 15, 20, 20, 15,  5,-30,},
			{-30,  0, 15, 20, 20, 15,  0,-30,},
			{-30,  5, 10, 15, 15, 10,  5,-30,},
			{-40,-20,  0,  5,  5,  0,-20,-40,},
			{-50,-40,-30,-30,-30,-30,-40,-50,}};

	/**
	 * Konstruiert einen neuen Spielstein an den gegebenen Koordinaten mit der gegebenen Farbe.
	 * @param x X-Koordinate
	 * @param y Y-Koordinate
	 * @param isWhite Farbe als boolean. true=weiß, false=scharz
	 */
	public Knight(int x, int y, boolean isWhite) {
		super(x, y, isWhite);
		this.setLetter("Kn");
		this.setValue(320);
		squareTable=pieceTable;
	}
	
	/**
	 * Gibt an, ob sich eine Spielfigur an die neue Position bewegen kann.
	 * @param x neue X-Koordinate
	 * @param y neue Y-Koordinate
	 * @param b das Spielbrett
	 * @param checkCheck wird intern genutzt um ueberpruefungen ohne auswirkung aus das Spielfeld zu machen. Default=true.
	 * @return boolean
	 */
	public boolean canMoveTo(int x, int y, Board b, boolean checkCheck) {
	    if (!this.withinBounds(x, y)) {
	    	return false;
	    }
	    if (this.attackFriend(x, y, b)) {
	    	return false;
	    }

	    if (((int)Math.abs(x - this.getX()) == 2 && (int)Math.abs(y - this.getY()) == 1) || 
	    	((int)Math.abs(x - this.getX()) == 1 && (int)Math.abs(y - this.getY()) == 2)) {
	    	if(checkCheck) {
	    		if(!b.isCheck(this.isWhite(), x, y, this)) {
	    			return true;
	    		}
	    	}else {
	    		return true;
	    	}
	    }
	    return false;
	}
	
	/**
	 * Gibt eine Kopie der Spielsteins zurueck.
	 * @return ein neuer Spielstein.
	 */
	public Knight clone() {
		Knight cloned = new Knight(this.getX(), this.getY(), this.isWhite());
		cloned.setAlive(this.isAlive());
		return cloned;
	}
	
	/**
	 * Gibt alle moeglichen Zuege der Spielfigur als Collection von neuen Spielbrettern zurueck.
	 * (Wird fuer den AI-Algorithmus benoetigt)
	 * @param board das aktuelle SPielfeld
	 * @return eine Collection von Boards.
	 */
	public ArrayList<Board> getTurns(Board b){
		ArrayList<Board> boards= new ArrayList<Board>();
	
		for (int i=-2; i<3; i+=4) {
			for (int j=-1; j<2; j+=2) {
	
				int x = i + this.getX();
	        	int y = j + this.getY();
	        	if (!this.attackFriend(x, y, b) && this.withinBounds(x, y)) {
	        		if(!b.isCheck(this.isWhite(), x, y, this)) {
		        		Board cloned= b.clone();
		        		cloned.getPieceAt(this.getX(), this.getY()).move(x, y, cloned);
		        		boards.add(cloned);
	        		}
	          	}
			}
		}
		
		for (int i=-1; i<2; i+=2) {
			for (int j=-2; j<3; j+=4) {
				
				int x = i+this.getX();
				int y = j+this.getY();
				if (this.withinBounds(x, y) && !this.attackFriend(x, y, b)) {
					if(!b.isCheck(this.isWhite(), x, y, this)) {
						Board cloned= b.clone();
						cloned.getPieceAt(this.getX(), this.getY()).move(x, y, cloned);
						boards.add(cloned);
					}
				}
			}
		}
		    return boards;
	}
	

}
