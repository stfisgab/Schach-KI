package application;

import java.util.ArrayList;

/**
 * Implementierung der Spielsteines der Königin.
 * @author  Matscher Maximilian
 * @author  Gabriel Fischer
 */
public class Queen extends Piece {
	private static final long serialVersionUID = 6016352135094159754L;
	/**
	 * Beinhaltet eine 2-Dimensionales Array,je nach Position einen anderen
	 * Wert fuer den Spielstein festlegt. (Wird fuer den AI-Algorithmus gebraucht)
	 */
	static public int [][] pieceTable= {
			{-20,-10,-10, -5, -5,-10,-10,-20,},
			{-10,  0,  0,  0,  0,  0,  0,-10,},
			{-10,  0,  5,  5,  5,  5,  0,-10,},
			{-5,  0,  5,  5,  5,  5,  0, -5,},
			{0,  0,  5,  5,  5,  5,  0, -5,},
			{-10,  5,  5,  5,  5,  5,  0,-10,},
			{-10,  0,  5,  0,  0,  0,  0,-10,},
			{-20,-10,-10, -5, -5,-10,-10,-20}
	};
	
	/**
	 * Konstruiert einen neuen Spielstein an den gegebenen Koordinaten mit der gegebenen Farbe.
	 * @param x X-Koordinate
	 * @param y Y-Koordinate
	 * @param isWhite Farbe als boolean. true=weiß, false=scharz
	 */
	public Queen(int x, int y, boolean isWhite) {
		super(x, y, isWhite);
		this.setLetter("Q");
		this.setValue(900);
		squareTable=pieceTable;
	}
	
	/**
	 * Gibt an, ob sich eine Spielfigur an die neue Position bewegen kann.
	 * @param x neue X-Koordinate
	 * @param y neue Y-Koordinate
	 * @param b das Spielbrett
	 * @param checkCheck wird intern genutzt um ueberpruefungen ohne auswirkung aus das Spielfeld zu machen. Default=true.
	 * @return boolean
	 */
	public boolean canMoveTo(int x, int y, Board b, boolean checkCheck) {
		if (!this.withinBounds(x, y)) {
			return false;
		}
	    if (this.attackFriend(x, y, b)) {
	    	return false;
	    }
	    
	    if (x == this.getX() || y == this.getY()) {
	    	if (this.movesThroughPiece(x, y, b)) {
	    		return false;
	    	}
	    	if(checkCheck) {
		    	if(!b.isCheck(this.isWhite(), x, y, this)) {
		    		return true;
		    	}
	    	}else {
	    		return true;
	    	}
	    }
	    if (Math.abs(x - this.getX()) == Math.abs(y - this.getY())) {
	    	if (!this.movesThroughPiece(x, y, b)) {
	    		if(checkCheck) {
		    		if(!b.isCheck(this.isWhite(), x, y, this)) {
		    			return true;
		    		}
	    		}else {
	    			return true;
	    		}
	    	}
	    }
	    
	    return false;
	}
	
	/**
	 * Gibt eine Kopie der Spielsteins zurueck.
	 * @return ein neuer Spielstein.
	 */
	public Queen clone() {
		Queen cloned = new Queen(this.getX(), this.getY(), this.isWhite());
		cloned.setAlive(this.isAlive());
		return cloned;
	}
	
	/**
	 * Gibt alle möglichen Zuege der Spielfigur als Collection von neuen Spielbrettern zurueck.
	 * (Wird fuer den AI-Algorithmus benötigt)
	 * @param board das aktuelle Spielfeld
	 * @return eine Collection von Boards.
	 */
	public ArrayList<Board> getTurns(Board b){
		ArrayList<Board> boards= new ArrayList<Board>();
		for (int i = 0; i < 8; i++) {
			int x = i;
			int y = this.getY();
			if (x != this.getX()) {
		    	  if (!this.attackFriend(x, y, b) && !this.movesThroughPiece(x, y, b)) {
		    		  if(!b.isCheck(this.isWhite(), x, y, this)) {
		    			  Board cloned= b.clone();
		    			  cloned.getPieceAt(this.getX(), this.getY()).move(x, y, cloned);
		    			  boards.add(cloned);
		    		  }
		    	  }
			}
	    }
			    
		for (int i = 0; i < 8; i++) {
			int x = this.getX();
			int y = i;
			if (i != this.getY()) {
				if (!this.attackFriend(x, y, b) && !this.movesThroughPiece(x, y, b)) {
					if(!b.isCheck(this.isWhite(), x, y, this)) {
						Board cloned= b.clone();
						cloned.getPieceAt(this.getX(), this.getY()).move(x, y, cloned);
						boards.add(cloned);
					}
				}
			}
		}
	
		for (int i = 0; i < 8; i++) {
			int x = i;
			int y = this.getY() - (this.getX() - i);
			if (x != this.getX()) {
				if (this.withinBounds(x, y)) {
					if (!this.attackFriend(x, y, b) && !this.movesThroughPiece(x, y, b)) {
						if(!b.isCheck(this.isWhite(), x, y, this)) {
							Board cloned= b.clone();
							cloned.getPieceAt(this.getX(), this.getY()).move(x, y, cloned);
							boards.add(cloned);
						}
					}
				}
			}
		}
	
		for (int i = 0; i < 8; i++) {
			int x = this.getX() + (this.getY() - i);
			int y = i;
			if (x != this.getX()) {
				if (this.withinBounds(x, y)) {
					if (!this.attackFriend(x, y, b) && !this.movesThroughPiece(x, y, b)) {
						if(!b.isCheck(this.isWhite(), x, y, this)) {
							Board cloned= b.clone();
							cloned.getPieceAt(this.getX(), this.getY()).move(x, y, cloned);
							boards.add(cloned);
						}
					}
				}
			}
		}
		    return boards;
	}
}
