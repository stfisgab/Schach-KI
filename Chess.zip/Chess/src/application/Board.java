package application;

import java.util.ArrayList;

/**
 * Implementierung des Spielbretts
 * @author  Matscher Maximilian
 * @author  Gabriel Fischer
 */
public class Board {

	//Arrays mit allen Spielsteinen
	private Piece[] piecesBlack;
	private Piece[] piecesWhite;
	/**
	 * Enthält den Wert des Spielbretts
	 */
	private int value;

	public Piece[] getPiecesBlack() {
		return piecesBlack;
	}

	public void setPiecesBlack(Piece[] piecesBlack) {
		this.piecesBlack = piecesBlack;
	}

	public Piece[] getPiecesWhite() {
		return piecesWhite;
	}

	public void setPiecesWhite(Piece[] piecesWhite) {
		this.piecesWhite = piecesWhite;
	}

	/**
	 * Setzt den Spielbrettwert neu und gibt ihn zurück
	 * @return Spielbrettwert als integer
	 */
	public int getValue() {
		calcValue();
		return value;
	}

	/**
	 * Berechnet aus den Werten der einzelnen Spielfiguren den Wert des Spielbretts.
	 */
	public void calcValue() {
		int score=0;
		for(int i=0;i<16;i++) {
			Piece tmpWhite = piecesWhite[i];
			Piece tmpBlack = piecesBlack[i];
			if(tmpWhite.isAlive()) {
				score-=tmpWhite.getValue(tmpWhite.getX(),tmpWhite.getY());
			}
			if(tmpBlack.isAlive()) {
				score+=tmpBlack.getValue(tmpBlack.getX(),tmpBlack.getY());
			}
		}
		this.value=score;
	}

	/**
	 * Konstruiert ein neues Spielbrett mit den Spielsteinen an den Startpositionen
	 */
	public Board(){
		piecesBlack=new Piece[16];
		piecesWhite=new Piece[16];
		
		
		piecesWhite[0]=new King(4, 7, true);
		piecesWhite[1]=new Queen(3, 7, true);
		piecesWhite[2]=new Bishop(2, 7, true);
		piecesWhite[3]=new Bishop(5, 7, true);
		piecesWhite[4]=new Knight(1, 7, true);
		piecesWhite[5]=new Rook(0, 7, true);
		piecesWhite[6]=new Knight(6, 7, true);
		piecesWhite[7]=new Rook(7, 7, true);

		piecesWhite[8]=new Pawn(4, 6, true);
		piecesWhite[9]=new Pawn(3, 6, true);
		piecesWhite[10]=new Pawn(2, 6, true);
		piecesWhite[11]=new Pawn(5, 6, true);
		piecesWhite[12]=new Pawn(1, 6, true);
		piecesWhite[13]=new Pawn(0, 6, true);
		piecesWhite[14]=new Pawn(6, 6, true);
		piecesWhite[15]=new Pawn(7, 6, true);

	    piecesBlack[0]=new King(4, 0, false);
	    piecesBlack[1]=new Queen(3, 0, false);
	    piecesBlack[2]=new Bishop(2, 0, false);
	    piecesBlack[3]=new Bishop(5, 0, false);
	    piecesBlack[4]=new Knight(1, 0, false);
	    piecesBlack[5]=new Rook(0, 0, false);
	    piecesBlack[6]=new Knight(6, 0, false);
	    piecesBlack[7]=new Rook(7, 0, false);

	    piecesBlack[8]=new Pawn(4, 1, false);
	    piecesBlack[9]=new Pawn(3, 1, false);
	    piecesBlack[10]=new Pawn(2, 1, false);
	    piecesBlack[11]=new Pawn(5, 1, false);
	    piecesBlack[12]=new Pawn(1, 1, false);
	    piecesBlack[13]=new Pawn(0, 1, false);
	    piecesBlack[14]=new Pawn(6, 1, false);
	    piecesBlack[15]=new Pawn(7, 1, false);
	}
	
	/**
	 * Gibt die Spielfigur an der gegebenen Position zurück.
	 * @param x X-Koordinate
	 * @param y Y-Koordinate
	 * @return
	 */
	public Piece getPieceAt(int x, int y) {
		for(int i=0; i<16;i++) {
			if(piecesBlack[i].getX()==x && piecesBlack[i].getY()==y && piecesBlack[i].isAlive()) return piecesBlack[i];
			if(piecesWhite[i].getX()==x && piecesWhite[i].getY()==y && piecesWhite[i].isAlive()) return piecesWhite[i];
		}
		return null;
	}
	
	/**
	 * Gibt ein Array mit allen möglichen Zugen der schwarzen Spielsteine zurück.
	 * @return Array mit Boards
	 */
	public ArrayList<Board> getTurnsBlack(){
		ArrayList<Board> boards= new ArrayList<Board>();
		for(int i=0; i<16;i++) {
			if(piecesBlack[i].isAlive()) boards.addAll(piecesBlack[i].getTurns(this));
		}
		if(boards.size()==0) boards.add(this);
		return boards;
	}
	
	/**
	 * Gibt ein Array mit allen möglichen Zugen der weissen Spielsteine zurück.
	 * @return Array mit Boards
	 */
	public ArrayList<Board> getTurnsWhite(){
		ArrayList<Board> boards= new ArrayList<Board>();
		for(int i=0; i<16;i++) {
			if(piecesWhite[i].isAlive()) boards.addAll(piecesWhite[i].getTurns(this));
		}
		if(boards.size()==0) boards.add(this);
		return boards;
	}
	
	/**
	 * Gibt eine Kopie des Spielbretts zurück.
	 */
	public Board clone() {
		Board cloned= new Board();
		Piece[] piecesBlack= new Piece[16];
		for(int i=0; i<16;i++) {
			piecesBlack[i]= this.piecesBlack[i].clone();
		}
		cloned.setPiecesBlack(piecesBlack);
		Piece[] piecesWhite= new Piece[16];
		for(int i=0; i<16;i++) {
			piecesWhite[i]= this.piecesWhite[i].clone();
		}
		cloned.setPiecesWhite(piecesWhite);
		return cloned;
	}
	
	/**
	 * Gibt an ob das Spiel beendet ist.
	 * @return boolean
	 */
	public boolean isDone() {
	    return !this.piecesWhite[0].isAlive() || !this.piecesBlack[0].isAlive();
	 }
	public boolean isDone(boolean isWhite) {
		if(!this.piecesWhite[0].isAlive() || !this.piecesBlack[0].isAlive()) {
			return true;
		}
		if(isWhite) {
			if(getTurnsWhite().contains(this)) {
				return true;
			}
		}else {
			if(getTurnsBlack().contains(this)) {
				return true;
			}
		}
	    return false;
	 }
	/**
	 * Gibt an, ob ein Spieler schach ist.
	 * @param isWhite Spieler der an der Reihe ist
	 * @param x X-Koordinate
	 * @param y Y-Koordinate
	 * @param p Spielstein
	 * @return boolean
	 */
	public boolean isCheck(boolean isWhite, int x, int y, Piece p) {
		int prevX=p.getX();
		int prevY=p.getY();
		Board tmp = this.clone();
		tmp.getPieceAt(prevX, prevY).move(x, y, tmp);
		boolean check;
		if(isWhite) {
			check = ((King)tmp.piecesWhite[0]).isCheck(tmp, isWhite);
			tmp.getPieceAt(x, y).moveNoAttack(prevX,prevY);
			return check;
		}else {
			check = ((King)tmp.piecesBlack[0]).isCheck(tmp, isWhite);
			tmp.getPieceAt(x, y).moveNoAttack(prevX,prevY);
			return check;
		}
	}
	
	/**
	 * Gibt das Spielbrett mit den Figuren als String zurück.
	 */
	public String toString() {
		StringBuilder sb= new StringBuilder();
		for(int i=0; i<8; i++) {
			for(int j=0; j<8; j++) {
				if(this.getPieceAt(j,i)!=null) {
					sb.append(this.getPieceAt(j,i).getLetter()+"."+this.getPieceAt(j,i).isWhite()+" ");
				}
				else sb.append("_ ");
			}
			sb.append("\n");
		}
		return sb.toString();
	}

	/**
	 * Testet ob sich der Spielstand im Endgame befindet.
	 * @return boolean
	 */
	public boolean isEndgame() {
		if(!piecesBlack[1].isAlive() && !piecesWhite[1].isAlive()) {
			return true;
		}
		if(piecesBlack[1].isAlive() && minorPiecesAlive(piecesBlack)<1) {
			return true;
		}
		if(piecesWhite[1].isAlive() && minorPiecesAlive(piecesWhite)<1) {
			return true;
		}
		return false;
	}
	private int minorPiecesAlive(Piece[] pieces) {
		int pieceCount =0;
		
		for(int i=2;i<7;i++) {
			if(pieces[i].isAlive())pieceCount++;
		}
		return pieceCount;
	}

}
