package application;

import java.io.Serializable;
import java.util.Collection;

/**
 * Implementierung eines abstrakten Spielsteines. Alle anderen Spielsteine erben von diesem.
 * Beinhaltet alle gemeinsamen Eigenschaften der Spielsteine.
 * @author  Matscher Maximilian
 * @author  Gabriel Fischer
 */
public abstract class Piece implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2411247420134830300L;
	
	/**
	 * Beinhaltet eine 2-Dimensionales Array, das je nach Spielstein, je nach Position einen anderen
	 * Wert fuer den Spielstein festlegt. (Wird fuer den AI-Algorithmus gebraucht)
	 */
	public int [][] squareTable;
	/**
	 * X-Koordinate im Spielbrett.
	 */
	private int x;
	/**
	 * Y-Koordinate im Spielbrett.
	 */
	private int y;
	/**
	 * Gibt an, ob die Spielfigur weiss ist, oder nicht.
	 */
	private boolean isWhite;
	/**
	 * Gibt an, ob die Spielfigur bereits aus dem Spiel ist.
	 */
	private boolean isAlive=true;
	/**
	 * Speichert den Wert der Spielfigur.(je nach art der Spielfigur verschieden)
	 */
	private int value;
	/**
	 * Speichert den  Buchstaben der Spielfigur.
	 * (Wurde anfangs beim Prototyp statt Figurenbild genutzt, spaeter als Bezeichner)
	 */
	private String letter;

	/**
	 * Konstruiert einen neuen Spielstein an den gegebenen Koordinaten mit der gegebenen Farbe.
	 * @param x X-Koordinate
	 * @param y Y-Koordinate
	 * @param isWhite Farbe als boolean. true=weiß, false=scharz
	 */
	public Piece(int x, int y, boolean isWhite) {
		this.x=x;
		this.y=y;
		this.isWhite=isWhite;
	}
	
	/**
	 * Gibt die X-Koordinate im Spielbrett zurueck
	 * @return die X-Koordinate als Integer zwischen 0 und 7.
	 */
	public int getX() {
		return x;
	}
	/**
	 * Setzt die X-Koordinate im Spielbrett
	 * @param x die neue x-Koordinate als Integer zwischen 0 und 7.
	 */
	public void setX(int x) {
		this.x = x;
	}

	/**
	 * Gibt die Y-Koordinate im Spielbrett zurueck
	 * @return die Y-Koordinate als Integer zwischen 0 und 7.
	 */
	public int getY() {
		return y;
	}

	/**
	 * Setzt die Y-Koordinate im Spielbrett
	 * @param y die neue Y-Koordinate als Integer zwischen 0 und 7.
	 */
	public void setY(int y) {
		this.y = y;
	}

	/**
	 * Gibt zurueck, ob die Spielfigur weiß ist.
	 * @return die Farbe. true, wenn die Figur weiß ist, false, wenn die Figur schwarz ist.
	 */
	public boolean isWhite() {
		return isWhite;
	}

	/**
	 * Setzt die Farbe der Spielfigur.
	 * @param isWhite die neue Farbe. true, wenn die Figur weiß ist, false, wenn die Figur schwarz ist.
	 */
	public void setWhite(boolean isWhite) {
		this.isWhite = isWhite;
	}

	/**
	 * Gibt zurueck ob die Spielfigur noch im Spiel ist.
	 * @return true, wenn die Spielfigur noch im Spiel ist, false wenn nicht.
	 */
	public boolean isAlive() {
		return isAlive;
	}

	/**
	 * Setzt isAlive.
	 * @param isAlive true, wenn die Spielfigur noch im Spiel ist, false wenn nicht.
	 */
	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

	/**
	 * Gibt den Wert der Spielfigur, je nach Position am Spielbrett zurueck
	 * @param x X-Koordinate auf dem Spielbrett
	 * @param y X-Koordinate auf dem Spielbrett
	 * @return den Spielsteinwert, als Integer.
	 */
	public int getValue(int x, int y) {
		if(isWhite) {
			return value + this.squareTable[y][x];
		}else {
			return value + this.squareTable[7-y][x];
		}
	}

	/**
	 * Setzt den Spielsteinwert.
	 * @param value Der neue Wert des Spielsteins, als Integer.
	 */
	public void setValue(int value) {
		this.value = value;
	}

	/**
	 * Gibt den Kennzeichnungs-Buchstaben des Spielsteins zurueck.
	 * @return der Buchstabe als String.
	 */
	public String getLetter() {
		return letter;
	}

	/**
	 * Setzt den Kennzeichnungs-Buchstaben des Spielsteins.
	 * @param letter der neue Buchstabe, als String.
	 */
	public void setLetter(String letter) {
		this.letter = letter;
	}
	
	/**
	 * Bewegt einen Spielstein an eine neue Postition im Spielbrett. Nimmt andere
	 * Spielsteine aus dem Spiel, wenn sich an der neuen Position irgendwelche befinden.
	 * @param x neue X-Koordinate
	 * @param y neue Y-Koordinate
	 * @param b das Spielbrett
	 */
	public void move(int x,int y, Board b) {
		Piece attacking = b.getPieceAt(x, y);
		if(attacking != null && attacking !=this) {
			attacking.setAlive(false);
		}
		this.setX(x);
		this.setY(y);
	}
	
	/**
	 * Gibt an, ob sich eine Spielfigur an die neue Position bewegen kann.
	 * @param x neue X-Koordinate
	 * @param y neue Y-Koordinate
	 * @param b das Spielbrett
	 * @param checkCheck wird intern genutzt um ueberpruefungen ohne auswirkung aus das Spielfeld zu machen. Default=true.
	 * @return boolean
	 */
	public boolean canMoveTo(int x,int y,Board b, boolean checkCheck) {
	    if (!this.withinBounds(x, y)) {
	      return false;
	    }
	    return true;
	  }
	
	/**
	 * Gibt an ob sich die angegebenen Koordinaten, noch im Spielfeld befinden.
	 * @param x X-Koordinate
	 * @param y Y-Koordinate
	 * @return boolean
	 */
	public boolean withinBounds(int x,int y) {

	    if (x >= 0 && y >= 0 && x < 8 && y < 8) {
	      return true;
	    }
	    return false;

	  }
	
	/**
	 * Gibt an, ob sich auf den angegebenen Feld ein freundlicher Spielstein befindet.
	 * @param x X-Koordinate
	 * @param y Y-Koordinate
	 * @param b Spielfeld
	 * @return boolean
	 */
	public boolean attackFriend(int x,int y, Board b) {
	    Piece attacking = b.getPieceAt(x, y);
	    if (attacking != null) {
	      if (attacking.isWhite == this.isWhite) {
	        return true;
	      }
	    }
	    return false;
	  }
	
	/**
	 * Gibt an, ob sich ein Spielstein beim Bewegen durch ein anderes durchbewegt.
	 * (Außer von Springer verboten)
	 * @param x X-Koordinate der Zielposition.
	 * @param y Y-Koordinate der Zielposition.
	 * @param b Spielbrett
	 * @return boolean
	 */
	public boolean movesThroughPiece(int x, int y, Board b) {
		int dirX = x - this.getX();
	    dirX=(int) Math.signum(dirX);
	    int dirY = y - this.getY();
	    dirY=(int) Math.signum(dirY);
	    
	    int tmpX = this.getX()+dirX;
	    int tmpY = this.getY()+dirY;
	    while (tmpX != x || tmpY != y) {
	    	if (b.getPieceAt(tmpX, tmpY) != null) {
	    		return true;
	    	}
	    	tmpX+=dirX;
	    	tmpY+=dirY;
	    }
	    return false;
	}
	
	/**
	 * Gibt alle moeglichen Zuege der Spielfigur als Collection von neuen Spielbrettern zurueck.
	 * (Wird fuer den AI-Algorithmus benoetigt)
	 * @param board das aktuelle SPielfeld
	 * @return eine Collection von Boards.
	 */
	public Collection<Board> getTurns(Board board) {
		return null;
	}
	
	/**
	 * Gibt eine Kopie der Spielsteins zurueck.
	 * @return ein neuer Spielstein.
	 */
	public Piece clone() {
		return null;
	}
	
	/**
	 * Gewegt einen Spielstein an die gegebene Position, ohne ueberpfuefung auf Angriffe.
	 * @param x neue X-Koordinate
	 * @param y neue Y-Koordinate
	 */
	public void moveNoAttack(int x, int y) {
		this.setX(x);
		this.setY(y);
	}
	
	public boolean equals(Object o) {
		if(o==null) return false;
		Piece p= (Piece) o;
		if(p.letter!=this.letter) return false;
		if(p.getX()!=this.getX()) return false;
		if(p.getY()!=this.getY()) return false;
		if(p.isAlive!=this.isAlive) return false;
		return true;
	}

}
